package genericCheckpointing.xmlStoreRestore;

import genericCheckpointing.util.SerializableObject;

public class XMLSerialization implements SerStrategy {

	public XMLSerialization() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void processInput(SerializableObject sObject) {
		// TODO Auto-generated method stub
		
	}

}
	