package genericCheckpointing.xmlStoreRestore;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import genericCheckpointing.util.SerializableObject;

public class StoreRestoreHandler implements InvocationHandler {

	String fileName;
	BufferedWriter writer;
	BufferedReader reader;

	public Object invoke(Object proxy, Method m, Object[] args) throws Throwable {
		if (m.getName() == "setFileName") {
			fileName = (String) args[0];
		} else if (m.getName() == "openFile") {
			try {
				System.out.println("File Open");
				writer = new BufferedWriter(new FileWriter(fileName, true));
				reader = new BufferedReader(new FileReader(fileName));
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		} else if (m.getName() == "closeFile") {
			try {
				writer.close();
				reader.close();
				System.out.println("File Closed");
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else if (m.getName() == "readObj") {
			String line = reader.readLine();
			while (line != null) {
				if (line.substring(1, 16).equalsIgnoreCase("DPSerialization")) {
					createObject();
				}
			}
		}

		// if the method is write
		// if the wireFormat is XML
		//  call serializeData(args[0], new XMLSerializationStrategy());

		// if statements to check if it is the read method so that
		// deserialization can be done ... 

		return args;
	}

	public void serializeData(SerializableObject sObject, SerStrategy sStrategy) {
		sStrategy.processInput(sObject);
	}

	private void createObject( ) throws IOException {
		String line = reader.readLine();
		while (line != null && line.substring(2, 17).equalsIgnoreCase("DPSerialization")) {
			Pattern p = Pattern.compile("\"([^\"]*)\"");
			Matcher m = p.matcher(line);
			m.find();
		}
	}
}
