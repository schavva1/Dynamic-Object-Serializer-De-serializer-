package genericCheckpointing.util;

//A tag interface (also called a marker interface) is simply an interface with no methods
public class SerializableObject {

	public SerializableObject() {
		// TODO Auto-generated constructor stub
	}

}
