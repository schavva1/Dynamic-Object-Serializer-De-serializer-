package genericCheckpointing.util;

public class MyAllTypesFirst extends SerializableObject{

	public MyAllTypesFirst() {
		// TODO Auto-generated constructor stub
		
	}

}
