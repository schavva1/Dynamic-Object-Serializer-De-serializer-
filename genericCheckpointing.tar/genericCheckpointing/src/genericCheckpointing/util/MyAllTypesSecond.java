package genericCheckpointing.util;

public class MyAllTypesSecond extends SerializableObject{

	public MyAllTypesSecond() {
		// TODO Auto-generated constructor stub
		
		
	}
	int myint;
	long mylong;
	String mystring;
	public int getMyint() {
		return myint;
	}
	public void setMyint(int myint) {
		this.myint = myint;
	}
	public long getMylong() {
		return mylong;
	}
	public void setMylong(long mylong) {
		this.mylong = mylong;
	}
	public String getMystring() {
		return mystring;
	}
	public void setMystring(String mystring) {
		this.mystring = mystring;
	}
	
	
	
}
