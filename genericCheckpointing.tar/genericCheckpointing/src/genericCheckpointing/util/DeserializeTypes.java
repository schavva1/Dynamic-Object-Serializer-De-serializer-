package genericCheckpointing.util;

public class DeserializeTypes {

	public DeserializeTypes() {
		// TODO Auto-generated constructor stub
	}

}
