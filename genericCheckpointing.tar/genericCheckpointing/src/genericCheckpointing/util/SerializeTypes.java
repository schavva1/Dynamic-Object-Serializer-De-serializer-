package genericCheckpointing.util;

public class SerializeTypes {

	public SerializeTypes() {
		// TODO Auto-generated constructor stub
	}

}
