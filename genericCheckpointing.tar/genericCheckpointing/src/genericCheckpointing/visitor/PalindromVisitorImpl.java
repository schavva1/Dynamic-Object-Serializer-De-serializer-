package genericCheckpointing.visitor;

public class PalindromVisitorImpl {

	public PalindromVisitorImpl() {
		// TODO Auto-generated constructor stub
	}

}
