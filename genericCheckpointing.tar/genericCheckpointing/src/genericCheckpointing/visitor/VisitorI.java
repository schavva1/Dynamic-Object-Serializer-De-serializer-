package genericCheckpointing.visitor;

public interface VisitorI {

}
