package genericCheckpointing.visitor;

public class PrimeVisitorImpl {

	public PrimeVisitorImpl() {
		// TODO Auto-generated constructor stub
	}

}
